package com.hpprint.simple

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.pdf.PdfRenderer
import android.media.ExifInterface
import android.net.Uri
import android.os.ParcelFileDescriptor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Lays source pages out on an A4 bitmap (full sheet, A5 half sheet, N-up). */
class Render(private val cr: ContentResolver, private val dpi: Int, private val o: Opts) {
    private val renderers = HashMap<Uri, PdfRenderer>()
    private val fds = ArrayList<ParcelFileDescriptor>()

    private fun px(mm: Double) = (mm / 25.4 * dpi).roundToInt()
    val pageW = px(210.0)
    val pageH = px(297.0)

    fun close() {
        for (r in renderers.values) try { r.close() } catch (e: Exception) {}
        for (f in fds) try { f.close() } catch (e: Exception) {}
        renderers.clear(); fds.clear()
    }

    fun sheet(batch: List<Src>): Bitmap {
        val bmp = Bitmap.createBitmap(pageW, pageH, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.WHITE)
        val c = Canvas(bmp)
        val n = o.nUp
        val rw: Int
        val rh: Int
        if (o.a5) {
            // A5 landscape = one half of the A4 sheet (top or bottom)
            rw = pageW; rh = pageH / 2
            c.translate(0f, if (o.bottom) (pageH - rh).toFloat() else 0f)
        } else if (n == 2 || n == 6) {
            // 2 and 6 per sheet use a landscape layout, rotated onto the portrait sheet
            rw = pageH; rh = pageW
            c.translate(pageW.toFloat(), 0f)
            c.rotate(90f)
        } else {
            rw = pageW; rh = pageH
        }
        val cols = when (n) { 1 -> 1; 2 -> 2; 4 -> 2; 6 -> 3; else -> 3 }
        val rows = when (n) { 1 -> 1; 2 -> 1; 4 -> 2; 6 -> 2; else -> 3 }
        val m = px(5.0)
        val cw = rw / cols
        val ch = rh / rows
        for ((i, s) in batch.withIndex()) {
            val cx = i % cols
            val cy = i / cols
            val cell = Rect(cx * cw + m, cy * ch + m, (cx + 1) * cw - m, (cy + 1) * ch - m)
            val img = try { load(s, cell.width(), cell.height()) } catch (e: Exception) { null } ?: continue
            c.save()
            c.clipRect(cell)
            c.drawBitmap(
                img,
                cell.left + (cell.width() - img.width) / 2f,
                cell.top + (cell.height() - img.height) / 2f,
                null
            )
            c.restore()
            img.recycle()
        }
        return bmp
    }

    private fun scaleFor(w: Double, h: Double, cw: Int, ch: Int): Double {
        val a = cw / w
        val b = ch / h
        return if (o.fill) max(a, b) else min(a, b)
    }

    private fun load(s: Src, cw: Int, ch: Int): Bitmap? = if (s.pdf) loadPdf(s, cw, ch) else loadImage(s, cw, ch)

    private fun loadPdf(s: Src, cw: Int, ch: Int): Bitmap {
        val r = renderers.getOrPut(s.uri) {
            val fd = cr.openFileDescriptor(s.uri, "r") ?: throw IllegalStateException("Can't open PDF")
            fds.add(fd)
            PdfRenderer(fd)
        }
        val page = r.openPage(s.index)
        try {
            val sc = scaleFor(page.width.toDouble(), page.height.toDouble(), cw, ch)
            val bw = max(1, (page.width * sc).roundToInt())
            val bh = max(1, (page.height * sc).roundToInt())
            val b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            b.eraseColor(Color.WHITE)
            page.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
            return b
        } finally {
            page.close()
        }
    }

    private fun rotation(u: Uri): Int = try {
        cr.openInputStream(u)!!.use {
            when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                6 -> 90; 3 -> 180; 8 -> 270; else -> 0
            }
        }
    } catch (e: Exception) { 0 }

    private fun loadImage(s: Src, cw: Int, ch: Int): Bitmap? {
        val bo = BitmapFactory.Options()
        bo.inJustDecodeBounds = true
        cr.openInputStream(s.uri)?.use { BitmapFactory.decodeStream(it, null, bo) }
        if (bo.outWidth <= 0 || bo.outHeight <= 0) return null
        val rot = rotation(s.uri)
        val swap = rot == 90 || rot == 270
        val iw = if (swap) bo.outHeight else bo.outWidth
        val ih = if (swap) bo.outWidth else bo.outHeight
        val sc = scaleFor(iw.toDouble(), ih.toDouble(), cw, ch)
        var sample = 1
        while (sample * 2 <= 1.0 / sc) sample *= 2
        val dec = BitmapFactory.Options()
        dec.inSampleSize = sample
        val src = cr.openInputStream(s.uri)?.use { BitmapFactory.decodeStream(it, null, dec) } ?: return null
        val f = (sc * sample).toFloat()
        val mx = Matrix()
        mx.postRotate(rot.toFloat())
        mx.postScale(f, f)
        val out = Bitmap.createBitmap(src, 0, 0, src.width, src.height, mx, true)
        if (out !== src) src.recycle()
        return out
    }
}
