package com.hpprint.simple

import android.graphics.Bitmap
import java.io.OutputStream
import java.nio.ByteBuffer

/** PWG Raster (image/pwg-raster) writer: 8-bit grayscale, A4. */
object Pwg {
    private fun header(w: Int, h: Int, dpi: Int, pages: Int): ByteArray {
        val b = ByteBuffer.allocate(1796)
        fun s(off: Int, t: String) { val x = t.toByteArray(Charsets.US_ASCII); for (i in x.indices) b.put(off + i, x[i]) }
        fun i(off: Int, v: Int) { b.putInt(off, v) }
        s(0, "PwgRaster")
        i(276, dpi); i(280, dpi)      // HWResolution
        i(340, 1)                     // NumCopies
        i(352, 595); i(356, 842)      // PageSize in points (A4)
        i(372, w); i(376, h)
        i(384, 8); i(388, 8); i(392, w)
        i(396, 0)                     // chunky
        i(400, 18)                    // sGray
        i(420, 1)                     // NumColors
        i(452, pages)                 // TotalPageCount
        i(456, 1); i(460, 1)          // cross-feed / feed transform
        i(464, 0); i(468, 0); i(472, w); i(476, h) // image box
        s(1732, "iso_a4_210x297mm")
        return b.array()
    }

    fun start(out: OutputStream) { out.write("RaS2".toByteArray(Charsets.US_ASCII)) }

    fun writePage(out: OutputStream, bmp: Bitmap, dpi: Int, pages: Int) {
        val w = bmp.width
        val h = bmp.height
        out.write(header(w, h, dpi, pages))
        val px = IntArray(w)
        val cur = ByteArray(w)
        var prev: ByteArray? = null
        var rep = 0
        for (y in 0 until h) {
            bmp.getPixels(px, 0, w, 0, y, w, 1)
            for (x in 0 until w) {
                val c = px[x]
                cur[x] = ((((c shr 16) and 255) * 299 + ((c shr 8) and 255) * 587 + (c and 255) * 114) / 1000).toByte()
            }
            val p = prev
            if (p != null && rep < 255 && cur.contentEquals(p)) {
                rep++
            } else {
                if (p != null) { out.write(rep); encode(p, out) }
                prev = cur.copyOf()
                rep = 0
            }
        }
        val p = prev
        if (p != null) { out.write(rep); encode(p, out) }
    }

    private fun encode(line: ByteArray, out: OutputStream) {
        var i = 0
        val n = line.size
        while (i < n) {
            var run = 1
            while (i + run < n && run < 128 && line[i + run] == line[i]) run++
            if (run >= 2) {
                out.write(run - 1); out.write(line[i].toInt() and 255)
                i += run
            } else {
                var j = i + 1
                while (j < n && j - i < 128 && !(j + 1 < n && line[j] == line[j + 1])) j++
                val cnt = j - i
                if (cnt == 1) {
                    out.write(0); out.write(line[i].toInt() and 255)
                } else {
                    out.write(257 - cnt); out.write(line, i, cnt)
                }
                i = j
            }
        }
    }
}
