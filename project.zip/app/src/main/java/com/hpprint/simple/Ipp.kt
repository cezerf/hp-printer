package com.hpprint.simple

import android.net.Network
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer

/** Minimal IPP 1.1 client: Get-Printer-Attributes and Print-Job. */
object Ipp {
    class Reply(val status: Int, val attrs: Map<String, List<ByteArray>>)

    class Printer(
        val ip: String, val path: String, val formats: List<String>,
        val dpis: List<Int>, val urf: List<String>, val copiesOk: Boolean
    ) {
        val uri: String get() = "ipp://$ip:631$path"
        val http: String get() = "http://$ip:631$path"
    }

    private fun put(o: ByteArrayOutputStream, tag: Int, name: String, v: ByteArray) {
        val n = name.toByteArray(Charsets.UTF_8)
        o.write(tag)
        o.write(n.size shr 8); o.write(n.size and 255)
        o.write(n, 0, n.size)
        o.write(v.size shr 8); o.write(v.size and 255)
        o.write(v, 0, v.size)
    }

    private fun text(o: ByteArrayOutputStream, tag: Int, name: String, v: String) =
        put(o, tag, name, v.toByteArray(Charsets.UTF_8))

    private fun begin(op: Int, uri: String): ByteArrayOutputStream {
        val o = ByteArrayOutputStream()
        o.write(1); o.write(1)                       // IPP version 1.1
        o.write(op shr 8); o.write(op and 255)       // operation id
        o.write(0); o.write(0); o.write(0); o.write(1) // request id
        o.write(1)                                   // operation-attributes group
        text(o, 0x47, "attributes-charset", "utf-8")
        text(o, 0x48, "attributes-natural-language", "en")
        text(o, 0x45, "printer-uri", uri)
        return o
    }

    private fun u16(d: ByteArray, p: Int) = ((d[p].toInt() and 255) shl 8) or (d[p + 1].toInt() and 255)

    private fun parse(d: ByteArray): Reply {
        if (d.size < 8) throw IOException("Bad reply from printer")
        val status = u16(d, 2)
        val attrs = HashMap<String, MutableList<ByteArray>>()
        var p = 8
        var last = ""
        while (p < d.size) {
            val tag = d[p].toInt() and 255
            p++
            if (tag < 0x10) {
                if (tag == 3) break
                continue
            }
            val nl = u16(d, p); p += 2
            val name = String(d, p, nl, Charsets.UTF_8); p += nl
            val vl = u16(d, p); p += 2
            val v = d.copyOfRange(p, p + vl); p += vl
            if (nl > 0) last = name
            attrs.getOrPut(last) { ArrayList() }.add(v)
        }
        return Reply(status, attrs)
    }

    private fun post(net: Network?, url: String, len: Long, body: (OutputStream) -> Unit): Reply {
        val u = URL(url)
        val c = (if (net != null) net.openConnection(u) else u.openConnection()) as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 8000
            c.readTimeout = 180000
            c.setRequestProperty("Content-Type", "application/ipp")
            c.setFixedLengthStreamingMode(len)
            val os = c.outputStream
            try { body(os) } finally { os.close() }
            val code = c.responseCode
            if (code != 200) throw IOException("HTTP $code")
            return parse(c.inputStream.readBytes())
        } finally {
            c.disconnect()
        }
    }

    fun probe(net: Network?, ip: String): Printer {
        var err: Exception? = null
        for (path in listOf("/ipp/print", "/ipp", "/ipp/printer")) {
            try {
                val o = begin(0x000B, "ipp://$ip:631$path")
                val want = listOf("document-format-supported", "pwg-raster-document-resolution-supported", "urf-supported", "copies-supported")
                want.forEachIndexed { i, w -> text(o, 0x44, if (i == 0) "requested-attributes" else "", w) }
                o.write(3)
                val b = o.toByteArray()
                val r = post(net, "http://$ip:631$path", b.size.toLong()) { it.write(b) }
                if (r.status >= 0x0400) { err = IOException("IPP status 0x" + r.status.toString(16)); continue }
                val formats = (r.attrs["document-format-supported"] ?: emptyList()).map { String(it, Charsets.UTF_8) }
                val dpis = (r.attrs["pwg-raster-document-resolution-supported"] ?: emptyList())
                    .filter { it.size >= 8 }.map { ByteBuffer.wrap(it).getInt(0) }
                val urf = (r.attrs["urf-supported"] ?: emptyList()).map { String(it, Charsets.UTF_8) }
                val copiesOk = r.attrs["copies-supported"]?.any { it.isNotEmpty() } == true
                return Printer(ip, path, formats, dpis, urf, copiesOk)
            } catch (e: Exception) {
                err = e
            }
        }
        throw IOException("Can't reach the printer at $ip (${err?.message})")
    }

    fun print(net: Network?, p: Printer, jobName: String, format: String, doc: File, copies: Int = 1) {
        val o = begin(0x0002, p.uri)
        text(o, 0x42, "requesting-user-name", "simpleprint")
        text(o, 0x42, "job-name", jobName)
        text(o, 0x49, "document-format", format)
        if (copies > 1) {
            o.write(2)  // job-attributes group
            put(o, 0x21, "copies", ByteBuffer.allocate(4).putInt(copies).array())
        }
        o.write(3)
        val head = o.toByteArray()
        val r = post(net, p.http, head.size + doc.length()) { out ->
            out.write(head)
            FileInputStream(doc).use { it.copyTo(out) }
        }
        if (r.status >= 0x0400) throw IOException("Printer refused the job (IPP 0x" + r.status.toString(16) + ")")
    }
}
