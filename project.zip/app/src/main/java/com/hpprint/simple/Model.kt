package com.hpprint.simple

import android.net.Uri

/** One source page: an image, or one page of a PDF. */
class Src(val uri: Uri, val pdf: Boolean, val index: Int)

class Opts(val a5: Boolean, val bottom: Boolean, val nUp: Int, val fill: Boolean)
