package com.hpprint.simple

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val files = ArrayList<Src>()
    private lateinit var ipEdit: EditText
    private lateinit var filesText: TextView
    private lateinit var statusText: TextView
    private lateinit var printBtn: Button
    private lateinit var posRow: LinearLayout
    private lateinit var copiesText: TextView
    private lateinit var previewView: ImageView
    private lateinit var pageText: TextView
    private var a5 = false
    private var bottom = false
    private var nUp = 1
    private var fill = false
    private var copies = 1
    private var rot = 0
    private var flipH = false
    private var flipV = false
    private var previewIdx = 0
    private var gen = 0

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(parent: LinearLayout, t: String) {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = 12f
        tv.setTextColor(0xFF9AA0A6.toInt())
        tv.setPadding(0, dp(20), 0, dp(4))
        parent.addView(tv)
    }

    private fun radios(labels: List<String>, checked: Int, onPick: (Int) -> Unit): RadioGroup {
        val g = RadioGroup(this)
        g.orientation = RadioGroup.HORIZONTAL
        val ids = labels.map { View.generateViewId() }
        labels.forEachIndexed { i, t ->
            val rb = RadioButton(this)
            rb.id = ids[i]
            rb.text = t
            rb.setTextColor(Color.WHITE)
            g.addView(rb)
        }
        g.check(ids[checked])
        g.setOnCheckedChangeListener { _, id -> onPick(ids.indexOf(id)) }
        return g
    }

    @Suppress("DEPRECATION")
    private fun gatewayIp(): String? {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val g = wm.dhcpInfo?.gateway ?: return null
        if (g == 0) return null
        return "${g and 255}.${(g shr 8) and 255}.${(g shr 16) and 255}.${(g shr 24) and 255}"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(24), dp(20), dp(32))

        val title = TextView(this)
        title.text = "dont spy me HP"
        title.textSize = 26f
        title.setTextColor(Color.WHITE)
        col.addView(title)

        label(col, "PRINTER IP  (first join the printer's Wi-Fi Direct network)")
        ipEdit = EditText(this)
        ipEdit.setSingleLine()
        ipEdit.setTextColor(Color.WHITE)
        ipEdit.setText(prefs.getString("ip", null) ?: gatewayIp() ?: "192.168.223.1")
        col.addView(ipEdit)
        val detect = Button(this)
        detect.text = "Detect from Wi-Fi"
        detect.setOnClickListener { gatewayIp()?.let { ipEdit.setText(it) } }
        col.addView(detect)

        label(col, "FILES")
        filesText = TextView(this)
        filesText.setTextColor(Color.WHITE)
        col.addView(filesText)
        val addBtn = Button(this)
        addBtn.text = "Add photos / PDFs"
        addBtn.setOnClickListener { pick() }
        col.addView(addBtn)
        val clearBtn = Button(this)
        clearBtn.text = "Clear list"
        clearBtn.setOnClickListener { files.clear(); refreshFiles() }
        col.addView(clearBtn)

        label(col, "PAPER")
        posRow = LinearLayout(this)
        posRow.orientation = LinearLayout.VERTICAL
        posRow.visibility = View.GONE
        col.addView(radios(listOf("A4", "A5 (half of an A4 sheet)"), 0) {
            a5 = it == 1
            posRow.visibility = if (a5) View.VISIBLE else View.GONE
            updatePreview()
        })
        label(posRow, "A5 POSITION ON THE SHEET")
        posRow.addView(radios(listOf("Top half", "Bottom half"), 0) { bottom = it == 1; updatePreview() })
        col.addView(posRow)

        label(col, "PAGES PER SHEET")
        val ups = listOf(1, 2, 4, 6, 9)
        col.addView(radios(ups.map { it.toString() }, 0) { nUp = ups[it]; refreshFiles() })

        label(col, "COPIES  (each sheet is printed this many times)")
        val copyRow = LinearLayout(this)
        copyRow.orientation = LinearLayout.HORIZONTAL
        copyRow.gravity = Gravity.CENTER_VERTICAL
        val minus = Button(this)
        minus.text = "−"
        copiesText = TextView(this)
        copiesText.text = "1"
        copiesText.textSize = 22f
        copiesText.setTextColor(Color.WHITE)
        copiesText.gravity = Gravity.CENTER
        val plus = Button(this)
        plus.text = "+"
        minus.setOnClickListener { if (copies > 1) { copies--; copiesText.text = copies.toString(); refreshText() } }
        plus.setOnClickListener { if (copies < 99) { copies++; copiesText.text = copies.toString(); refreshText() } }
        copyRow.addView(minus)
        copyRow.addView(copiesText, LinearLayout.LayoutParams(dp(70), LinearLayout.LayoutParams.WRAP_CONTENT))
        copyRow.addView(plus)
        col.addView(copyRow)

        label(col, "SCALING")
        col.addView(radios(listOf("Fit", "Fill (crop)"), 0) { fill = it == 1; updatePreview() })

        label(col, "ORIENTATION  (applies to every page)")
        val tools = LinearLayout(this)
        tools.orientation = LinearLayout.HORIZONTAL
        val rotBtn = Button(this)
        val fhBtn = Button(this)
        val fvBtn = Button(this)
        fun refreshTools() {
            rotBtn.text = "Rotate ${rot}°"
            fhBtn.text = if (flipH) "Flip ↔ ✓" else "Flip ↔"
            fvBtn.text = if (flipV) "Flip ↕ ✓" else "Flip ↕"
        }
        refreshTools()
        rotBtn.setOnClickListener { rot = (rot + 90) % 360; refreshTools(); updatePreview() }
        fhBtn.setOnClickListener { flipH = !flipH; refreshTools(); updatePreview() }
        fvBtn.setOnClickListener { flipV = !flipV; refreshTools(); updatePreview() }
        for (b in listOf(rotBtn, fhBtn, fvBtn)) {
            b.isAllCaps = false
            tools.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        col.addView(tools)

        label(col, "PREVIEW  (A4 sheet, black & white)")
        previewView = ImageView(this)
        previewView.setBackgroundColor(0xFF888888.toInt())
        previewView.setPadding(dp(1), dp(1), dp(1), dp(1))
        previewView.scaleType = ImageView.ScaleType.FIT_XY
        val bw = ColorMatrix()
        bw.setSaturation(0f)
        previewView.colorFilter = ColorMatrixColorFilter(bw)
        val pw = minOf(resources.displayMetrics.widthPixels - dp(40), dp(300))
        val plp = LinearLayout.LayoutParams(pw, pw * 297 / 210)
        plp.gravity = Gravity.CENTER_HORIZONTAL
        col.addView(previewView, plp)
        val nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.gravity = Gravity.CENTER
        val prev = Button(this)
        prev.text = "◀"
        prev.setOnClickListener { if (previewIdx > 0) { previewIdx--; updatePreview() } }
        pageText = TextView(this)
        pageText.setTextColor(Color.WHITE)
        pageText.gravity = Gravity.CENTER
        val next = Button(this)
        next.text = "▶"
        next.setOnClickListener { previewIdx++; updatePreview() }
        nav.addView(prev)
        nav.addView(pageText, LinearLayout.LayoutParams(dp(130), LinearLayout.LayoutParams.WRAP_CONTENT))
        nav.addView(next)
        col.addView(nav)

        printBtn = Button(this)
        printBtn.text = "PRINT"
        printBtn.textSize = 18f
        printBtn.setOnClickListener { startPrint(prefs.edit()) }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(28)
        col.addView(printBtn, lp)

        statusText = TextView(this)
        statusText.setTextColor(0xFF8AB4F8.toInt())
        statusText.setPadding(0, dp(12), 0, 0)
        col.addView(statusText)

        val sv = ScrollView(this)
        sv.setBackgroundColor(0xFF121212.toInt())
        sv.addView(col)
        setContentView(sv)
        refreshFiles()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun ui(f: () -> Unit) = runOnUiThread { f() }

    private fun sheetCount() = (files.size + nUp - 1) / nUp

    private fun refreshText() {
        if (files.isEmpty()) {
            filesText.text = "No files added yet"
        } else {
            val n = files.map { it.uri }.distinct().size
            val sheets = sheetCount()
            var t = "$n file(s), ${files.size} page(s) → $sheets sheet(s)"
            if (copies > 1) t += " × $copies copies = ${sheets * copies} sheets of paper"
            filesText.text = t
        }
    }

    private fun refreshFiles() {
        refreshText()
        updatePreview()
    }

    private fun updatePreview() {
        val g = ++gen
        val list = ArrayList(files)
        val o = Opts(a5, bottom, nUp, fill, 1, rot, flipH, flipV)
        val total = maxOf(1, sheetCount())
        if (previewIdx >= total) previewIdx = total - 1
        if (previewIdx < 0) previewIdx = 0
        val idx = previewIdx
        pageText.text = "Sheet ${idx + 1} / $total"
        Thread {
            val r = Render(contentResolver, 80, o)
            val batch: List<Src> = if (list.isEmpty()) emptyList()
            else list.subList(minOf(idx * nUp, list.size), minOf(list.size, (idx + 1) * nUp))
            val bmp: Bitmap? = try { r.sheet(batch) } catch (e: Throwable) { null } finally { r.close() }
            ui { if (g == gen && bmp != null) previewView.setImageBitmap(bmp) }
        }.start()
    }

    @Suppress("DEPRECATION")
    private fun pick() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "application/pdf"))
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        startActivityForResult(i, 1)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            val uris = ArrayList<Uri>()
            val cd = data.clipData
            if (cd != null) {
                for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri)
            } else {
                data.data?.let { uris.add(it) }
            }
            addUris(uris)
        }
    }

    @Suppress("DEPRECATION")
    private fun handleIntent(i: Intent?) {
        val intent = i ?: return
        val uris = ArrayList<Uri>()
        if (intent.action == Intent.ACTION_SEND) {
            val u: Uri? = if (Build.VERSION.SDK_INT >= 33)
                intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            else intent.getParcelableExtra(Intent.EXTRA_STREAM)
            if (u != null) uris.add(u)
        } else if (intent.action == Intent.ACTION_SEND_MULTIPLE) {
            val l: ArrayList<Uri>? = if (Build.VERSION.SDK_INT >= 33)
                intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
            else intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM)
            if (l != null) uris.addAll(l)
        }
        if (uris.isNotEmpty()) addUris(uris)
    }

    private fun addUris(uris: List<Uri>) {
        Thread {
            val found = ArrayList<Src>()
            for (u in uris) {
                try {
                    val mime = contentResolver.getType(u) ?: ""
                    if (mime == "application/pdf" || u.toString().lowercase().endsWith(".pdf")) {
                        val fd = contentResolver.openFileDescriptor(u, "r")
                        if (fd != null) {
                            val r = PdfRenderer(fd)
                            try { for (k in 0 until r.pageCount) found.add(Src(u, true, k)) }
                            finally { r.close(); fd.close() }
                        }
                    } else {
                        found.add(Src(u, false, 0))
                    }
                } catch (e: Exception) {
                    ui { statusText.text = "Can't read a file: ${e.message}" }
                }
            }
            ui { files.addAll(found); refreshFiles() }
        }.start()
    }

    private fun startPrint(ed: android.content.SharedPreferences.Editor) {
        if (files.isEmpty()) { statusText.text = "Add a photo or PDF first"; return }
        val ip = ipEdit.text.toString().trim()
        ed.putString("ip", ip).apply()
        val o = Opts(a5, bottom, nUp, fill, copies, rot, flipH, flipV)
        val list = ArrayList(files)
        printBtn.isEnabled = false
        Thread {
            try {
                PrintJob(this).run(ip, list, o) { m -> ui { statusText.text = m } }
                ui { statusText.text = "Sent to printer ✓" }
            } catch (e: Throwable) {
                ui { statusText.text = "Error: ${e.message ?: e.javaClass.simpleName}" }
            }
            ui { printBtn.isEnabled = true }
        }.start()
    }
}
