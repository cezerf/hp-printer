package com.hpprint.simple

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val files = ArrayList<Src>()
    private lateinit var ipEdit: EditText
    private lateinit var filesText: TextView
    private lateinit var statusText: TextView
    private lateinit var printBtn: Button
    private lateinit var posRow: LinearLayout
    private var a5 = false
    private var bottom = false
    private var nUp = 1
    private var fill = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(parent: LinearLayout, t: String) {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = 12f
        tv.setTextColor(0xFF9AA0A6.toInt())
        tv.setPadding(0, dp(20), 0, dp(4))
        parent.addView(tv)
    }

    private fun radios(labels: List<String>, checked: Int, onPick: (Int) -> Unit): RadioGroup {
        val g = RadioGroup(this)
        g.orientation = RadioGroup.HORIZONTAL
        val ids = labels.map { View.generateViewId() }
        labels.forEachIndexed { i, t ->
            val rb = RadioButton(this)
            rb.id = ids[i]
            rb.text = t
            rb.setTextColor(Color.WHITE)
            g.addView(rb)
        }
        g.check(ids[checked])
        g.setOnCheckedChangeListener { _, id -> onPick(ids.indexOf(id)) }
        return g
    }

    @Suppress("DEPRECATION")
    private fun gatewayIp(): String? {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val g = wm.dhcpInfo?.gateway ?: return null
        if (g == 0) return null
        return "${g and 255}.${(g shr 8) and 255}.${(g shr 16) and 255}.${(g shr 24) and 255}"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(24), dp(20), dp(32))

        val title = TextView(this)
        title.text = "Simple Print"
        title.textSize = 26f
        title.setTextColor(Color.WHITE)
        col.addView(title)

        label(col, "PRINTER IP  (first join the printer's Wi-Fi Direct network)")
        ipEdit = EditText(this)
        ipEdit.setSingleLine()
        ipEdit.setTextColor(Color.WHITE)
        ipEdit.setText(prefs.getString("ip", null) ?: gatewayIp() ?: "192.168.223.1")
        col.addView(ipEdit)
        val detect = Button(this)
        detect.text = "Detect from Wi-Fi"
        detect.setOnClickListener { gatewayIp()?.let { ipEdit.setText(it) } }
        col.addView(detect)

        label(col, "FILES")
        filesText = TextView(this)
        filesText.setTextColor(Color.WHITE)
        col.addView(filesText)
        val addBtn = Button(this)
        addBtn.text = "Add photos / PDFs"
        addBtn.setOnClickListener { pick() }
        col.addView(addBtn)
        val clearBtn = Button(this)
        clearBtn.text = "Clear list"
        clearBtn.setOnClickListener { files.clear(); refreshFiles() }
        col.addView(clearBtn)

        label(col, "PAPER")
        posRow = LinearLayout(this)
        posRow.orientation = LinearLayout.VERTICAL
        posRow.visibility = View.GONE
        col.addView(radios(listOf("A4", "A5 (half of an A4 sheet)"), 0) {
            a5 = it == 1
            posRow.visibility = if (a5) View.VISIBLE else View.GONE
        })
        label(posRow, "A5 POSITION ON THE SHEET")
        posRow.addView(radios(listOf("Top half", "Bottom half"), 0) { bottom = it == 1 })
        col.addView(posRow)

        label(col, "PAGES PER SHEET")
        val ups = listOf(1, 2, 4, 6, 9)
        col.addView(radios(ups.map { it.toString() }, 0) { nUp = ups[it]; refreshFiles() })

        label(col, "SCALING")
        col.addView(radios(listOf("Fit", "Fill (crop)"), 0) { fill = it == 1 })

        printBtn = Button(this)
        printBtn.text = "PRINT"
        printBtn.textSize = 18f
        printBtn.setOnClickListener { startPrint(prefs.edit()) }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(28)
        col.addView(printBtn, lp)

        statusText = TextView(this)
        statusText.setTextColor(0xFF8AB4F8.toInt())
        statusText.setPadding(0, dp(12), 0, 0)
        col.addView(statusText)

        val sv = ScrollView(this)
        sv.setBackgroundColor(0xFF121212.toInt())
        sv.addView(col)
        setContentView(sv)
        refreshFiles()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun ui(f: () -> Unit) = runOnUiThread { f() }

    private fun refreshFiles() {
        if (files.isEmpty()) {
            filesText.text = "No files added yet"
        } else {
            val n = files.map { it.uri }.distinct().size
            val sheets = (files.size + nUp - 1) / nUp
            filesText.text = "$n file(s), ${files.size} page(s) → $sheets sheet(s)"
        }
    }

    @Suppress("DEPRECATION")
    private fun pick() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "application/pdf"))
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        startActivityForResult(i, 1)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            val uris = ArrayList<Uri>()
            val cd = data.clipData
            if (cd != null) {
                for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri)
            } else {
                data.data?.let { uris.add(it) }
            }
            addUris(uris)
        }
    }

    @Suppress("DEPRECATION")
    private fun handleIntent(i: Intent?) {
        val intent = i ?: return
        val uris = ArrayList<Uri>()
        if (intent.action == Intent.ACTION_SEND) {
            val u: Uri? = if (Build.VERSION.SDK_INT >= 33)
                intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            else intent.getParcelableExtra(Intent.EXTRA_STREAM)
            if (u != null) uris.add(u)
        } else if (intent.action == Intent.ACTION_SEND_MULTIPLE) {
            val l: ArrayList<Uri>? = if (Build.VERSION.SDK_INT >= 33)
                intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
            else intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM)
            if (l != null) uris.addAll(l)
        }
        if (uris.isNotEmpty()) addUris(uris)
    }

    private fun addUris(uris: List<Uri>) {
        Thread {
            val found = ArrayList<Src>()
            for (u in uris) {
                try {
                    val mime = contentResolver.getType(u) ?: ""
                    if (mime == "application/pdf" || u.toString().lowercase().endsWith(".pdf")) {
                        val fd = contentResolver.openFileDescriptor(u, "r")
                        if (fd != null) {
                            val r = PdfRenderer(fd)
                            try { for (k in 0 until r.pageCount) found.add(Src(u, true, k)) }
                            finally { r.close(); fd.close() }
                        }
                    } else {
                        found.add(Src(u, false, 0))
                    }
                } catch (e: Exception) {
                    ui { statusText.text = "Can't read a file: ${e.message}" }
                }
            }
            ui { files.addAll(found); refreshFiles() }
        }.start()
    }

    private fun startPrint(ed: android.content.SharedPreferences.Editor) {
        if (files.isEmpty()) { statusText.text = "Add a photo or PDF first"; return }
        val ip = ipEdit.text.toString().trim()
        ed.putString("ip", ip).apply()
        val o = Opts(a5, bottom, nUp, fill)
        val list = ArrayList(files)
        printBtn.isEnabled = false
        Thread {
            try {
                PrintJob(this).run(ip, list, o) { m -> ui { statusText.text = m } }
                ui { statusText.text = "Sent to printer ✓" }
            } catch (e: Throwable) {
                ui { statusText.text = "Error: ${e.message ?: e.javaClass.simpleName}" }
            }
            ui { printBtn.isEnabled = true }
        }.start()
    }
}
