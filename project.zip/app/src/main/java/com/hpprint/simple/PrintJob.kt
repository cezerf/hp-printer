package com.hpprint.simple

import android.content.Context
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class PrintJob(private val ctx: Context) {

    @Suppress("DEPRECATION")
    private fun wifi(): Network? {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return cm.allNetworks.firstOrNull {
            cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        }
    }

    fun run(ip: String, srcs: List<Src>, o: Opts, say: (String) -> Unit) {
        say("Connecting to printer…")
        val net = wifi()
        val pr = Ipp.probe(net, ip)
        // If the printer doesn't list its formats, try PWG raster (required for Mopria printers).
        val fmts = if (pr.formats.isEmpty()) listOf("image/pwg-raster") else pr.formats
        val raster = "image/pwg-raster" in fmts &&
            (pr.dpis.isEmpty() || 300 in pr.dpis || "image/jpeg" !in fmts)
        if (!raster && "image/jpeg" !in fmts) {
            throw IOException("Printer doesn't accept PWG raster or JPEG. It reports: " + fmts.joinToString())
        }
        val dpi = if (raster && pr.dpis.isNotEmpty() && 300 !in pr.dpis) pr.dpis.min() else 300
        val batches = srcs.chunked(o.nUp)
        val tmp = File(ctx.cacheDir, "job.bin")
        val r = Render(ctx.contentResolver, dpi, o)
        try {
            if (raster) {
                BufferedOutputStream(FileOutputStream(tmp), 1 shl 16).use { out ->
                    Pwg.start(out)
                    batches.forEachIndexed { i, b ->
                        say("Preparing sheet ${i + 1} of ${batches.size}…")
                        val bmp = r.sheet(b)
                        Pwg.writePage(out, bmp, dpi, batches.size)
                        bmp.recycle()
                    }
                }
                say("Sending to printer…")
                Ipp.print(net, pr, "Simple Print", "image/pwg-raster", tmp)
            } else {
                batches.forEachIndexed { i, b ->
                    say("Sheet ${i + 1} of ${batches.size}…")
                    val bmp = r.sheet(b)
                    FileOutputStream(tmp).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                    bmp.recycle()
                    Ipp.print(net, pr, "Simple Print ${i + 1}", "image/jpeg", tmp)
                }
            }
        } finally {
            r.close()
            tmp.delete()
        }
    }
}
