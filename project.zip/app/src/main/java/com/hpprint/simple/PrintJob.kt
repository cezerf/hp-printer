package com.hpprint.simple

import android.content.Context
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class PrintJob(private val ctx: Context) {

    @Suppress("DEPRECATION")
    private fun wifi(): Network? {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return cm.allNetworks.firstOrNull {
            cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        }
    }

    fun run(ip: String, srcs: List<Src>, o: Opts, say: (String) -> Unit) {
        say("Connecting to printer…")
        val net = wifi()
        val pr = Ipp.probe(net, ip)
        // If the printer doesn't list its formats, try PWG raster (required for Mopria printers).
        val fmts = if (pr.formats.isEmpty()) listOf("image/pwg-raster") else pr.formats
        fun pick(l: List<Int>) = if (l.isEmpty() || 300 in l) 300 else l.min()
        val urfDpis = pr.urf.filter { it.startsWith("RS") }
            .flatMap { it.substring(2).split("-") }.mapNotNull { it.toIntOrNull() }
        val mode = when {
            "image/pwg-raster" in fmts && (pr.dpis.isEmpty() || 300 in pr.dpis) -> "pwg"
            "image/urf" in fmts -> "urf"
            "image/jpeg" in fmts -> "jpeg"
            "image/pwg-raster" in fmts -> "pwg"
            else -> throw IOException("Printer formats not supported: " + fmts.joinToString())
        }
        val raster = mode != "jpeg"
        val dpi = when (mode) { "pwg" -> pick(pr.dpis); "urf" -> pick(urfDpis); else -> 300 }
        val batches = srcs.chunked(o.nUp)
        val tmp = File(ctx.cacheDir, "job.bin")
        val r = Render(ctx.contentResolver, dpi, o)
        try {
            if (raster) {
                BufferedOutputStream(FileOutputStream(tmp), 1 shl 16).use { out ->
                    if (mode == "urf") Urf.start(out, batches.size) else Pwg.start(out)
                    batches.forEachIndexed { i, b ->
                        say("Preparing sheet ${i + 1} of ${batches.size}…")
                        val bmp = r.sheet(b)
                        if (mode == "urf") Urf.writePage(out, bmp, dpi) else Pwg.writePage(out, bmp, dpi, batches.size)
                        bmp.recycle()
                    }
                }
                say("Sending to printer…")
                Ipp.print(net, pr, "Simple Print", if (mode == "urf") "image/urf" else "image/pwg-raster", tmp)
            } else {
                batches.forEachIndexed { i, b ->
                    say("Sheet ${i + 1} of ${batches.size}…")
                    val bmp = r.sheet(b)
                    FileOutputStream(tmp).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                    bmp.recycle()
                    Ipp.print(net, pr, "Simple Print ${i + 1}", "image/jpeg", tmp)
                }
            }
        } finally {
            r.close()
            tmp.delete()
        }
    }
}
